import pygame
import random
import asyncio  # Required for web conversion

# 1. INITIALIZATION
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Supernatural: The Web Exorcism")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (200, 0, 0)
SALT_WHITE = (220, 220, 220)

# Game Constants
font = pygame.font.SysFont("Courier", 32)
rituals = ["Exorcizamus te", "Omnis immundus", "Spiritus", "Vade retro"]

# 2. ASYNC MAIN FUNCTION
async def main():
    # Game State Variables
    target_text = random.choice(rituals)
    user_input = ""
    score = 0
    demon_x = 700
    demon_speed = 1.0
    shake_offset = [0, 0]
    shake_frames = 0
    game_over = False

    clock = pygame.time.Clock()

    # THE MAIN GAME LOOP
    while True:
        screen.fill(BLACK)
        
        # Handle Screen Shake Logic
        if shake_frames > 0:
            shake_offset = [random.randint(-5, 5), random.randint(-5, 5)]
            shake_frames -= 1
        else:
            shake_offset = [0, 0]

        # 3. EVENT HANDLING
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return # Exit the function
            
            if not game_over:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        user_input = user_input[:-1]
                    elif event.key == pygame.K_RETURN:
                        if user_input.strip().lower() == target_text.lower():
                            score += 1
                            demon_x = 700 # Push back
                            demon_speed += 0.2
                            target_text = random.choice(rituals)
                            user_input = ""
                            shake_frames = 5 # Small success shake
                        else:
                            shake_frames = 20 # Big failure shake
                            user_input = ""
                    else:
                        user_input += event.unicode

        # 4. GAME LOGIC
        if not game_over:
            demon_x -= demon_speed
            if demon_x <= 150: # Salt line
                game_over = True

        # 5. RENDERING (With Shake Offset)
        # Draw Salt Line
        pygame.draw.line(screen, SALT_WHITE, (150 + shake_offset[0], 0), (150 + shake_offset[0], 600), 5)
        
        # Draw Demon
        pygame.draw.rect(screen, RED, (demon_x + shake_offset[0], 250 + shake_offset[1], 50, 50))
        
        # Draw Text
        prompt_surf = font.render(f"Type: {target_text}", True, WHITE)
        input_surf = font.render(f"> {user_input}", True, WHITE)
        score_surf = font.render(f"Banished: {score}", True, WHITE)
        
        screen.blit(prompt_surf, (200 + shake_offset[0], 100 + shake_offset[1]))
        screen.blit(input_surf, (200 + shake_offset[0], 150 + shake_offset[1]))
        screen.blit(score_surf, (20 + shake_offset[0], 20 + shake_offset[1]))

        if game_over:
            over_surf = font.render("THE DEMON CROSSED - GAME OVER", True, RED)
            screen.blit(over_surf, (WIDTH//2 - 250, HEIGHT//2))

        pygame.display.flip()
        
        # 6. THE "SECRET SAUCE" FOR WEB
        # This tells the browser: "I'm done with this frame, you can handle other tasks now."
        await asyncio.sleep(0) 
        clock.tick(60) # Limits to 60 FPS

# Start the async engine
asyncio.run(main())
